'use strict';
import dotenv from 'dotenv';
import serverless from 'serverless-http';
import express from 'express';

const app = express();
dotenv.config()

app.get("/", (req, res, next) => {
  return res.status(200).json({
    message: "Hello from root!",
  });
});

app.get("/hello", (req, res, next) => {
  return res.status(200).json({
    message: "Hello from path!",
  });
});

app.use((req, res, next) => {
  return res.status(404).json({
    error: "Not Found",
  });
});

module.exports.handler = serverless(app);

// module.exports.getUsers = async (event) => {
//   const mysql = require('mysql');
//   const connection = mysql.createConnection({
//     host: '',
//     user: '',
//     password: '',
//     database: '',
//   })

//   const p = new Promise((resolve) => {
//     connection.query('SELECT * FROM users', (err, result) => {
//       if(err) {
//         console.log(err);
//       }
//       resolve(result);
//     });
//   });

//   const result = await p;

//   return {
//     statusCode: 200,
//     body: JSON.stringify({results: result, test: 'hello world'}),
//   };
// };
